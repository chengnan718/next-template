### Issue 😱:

Closes https://github.com/Skolaczk/next-starter/issues

### What has been done ✅:

- [ ]

### Screenshots/Videos 🎥:

N/A
