export async function GET() {
  return Response.json({ health: true })
}
