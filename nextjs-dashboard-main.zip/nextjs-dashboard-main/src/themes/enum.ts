export enum Theme {
  Light = 'light',
  Dark = 'dark',
  Auto = 'auto',
}
