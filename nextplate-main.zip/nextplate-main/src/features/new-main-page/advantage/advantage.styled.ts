import styled from '@emotion/styled';

export const AdvantageRoot = styled.div({});
