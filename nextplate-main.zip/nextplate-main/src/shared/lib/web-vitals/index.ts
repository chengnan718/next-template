export { reportWebVitals } from './report-web-vitals';
export type { NextWebVitalsMetricsReport } from './types/next-web-vitals-metrics-report';
