import * as S from './alert-dialog.styled';

export * from '@radix-ui/react-alert-dialog';

export const { StyledOverlay, StyledContent } = S;
