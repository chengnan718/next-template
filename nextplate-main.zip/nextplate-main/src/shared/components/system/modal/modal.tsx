import * as S from './modal.styled';

export * from '@radix-ui/react-dialog';

export const { StyledOverlay, StyledContent } = S;
