export * from './delayed-loading';
