export const AppConfig = {
  site_name: 'React landing page',
  title: 'React landing page template',
  description: 'Production ready plug n play landing page!',
  locale: 'en',
};
