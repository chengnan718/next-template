
import InnerPageContainer from "@/components/common/InnerPageContainer";

export default function Page() {
    return (
      <InnerPageContainer title="Features">
      </InnerPageContainer>
    )
  }
  