import InnerPageContainer from "@/components/common/InnerPageContainer"

function Design() {
      return(
            <div className="grid place-items-center w-full bg-slate-100 pt-6 pb-48">
            <div className="max-w-5xl w-full  px-12 text-left flex-col ">
                  Blog List comming soon
            </div>
        </div>
      )

}

export default Design