<!-- Available h3 headings: Added, Fixed, Updated, Removed, Deprecated -->

# Changelog

All notable changes to this template will be documented in this file

## v2.0.0 (2024-06-18)

### Added

- Initial Release (Next.js v14 + App Router)

### Deprecated

- Next.js v12 version with Pages Router is now deprecated. You may access the deprecated version [here](https://github.com/themeselection/materio-mui-nextjs-admin-template-free/tree/nextjs-pages-router).

## v1.0.0 (2022-03-16)

### Added

- Initial Release
