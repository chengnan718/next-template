import "@/styles/globals.scss";
import { ReactNode } from "react";

const RootShell = ({ children }: { children: ReactNode }) => {
  return children;
};

export default RootShell;
