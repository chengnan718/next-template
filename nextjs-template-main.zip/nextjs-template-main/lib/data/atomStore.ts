import { createStore } from "jotai";

const atomStore = createStore();

export default atomStore;
